Menyoo PC by MAFINS.

Use the F8 key to open using the keyboard.
Use RB+Left to open using the gamepad.

Use the following keys to navigate:

Backspace - Back
Enter - Select
UpArrow - Up
DownArrow - Down
LeftArrow - Left
RightArrow - Right

Controller input:

B/Circle - Back
A/X - Select
DPAD Up - Up
DPAD Down - Down
DPAD Left - Left
DPAD Right - Right

You can change the keyboard and controller Menyoo open/close settings as well as other Menyoo defaults in the 'menyooConfig' file, which is found in the menyooStuff folder inside your GTA Directory. 

If you don't already have ScriptHookV, get it from here: http://www.dev-c.com/gtav/scripthookv/


How to install:
Place Menyoo.asi and menyooStuff (and any other important-looking files) in the GTA V directory.


